from django.db import models

class UserInput(models.Model):
    platform = models.CharField(max_length=20)  # Instagram, Twitter, Threads
    username = models.CharField(max_length=100)
    user_id = models.CharField(max_length=100, blank=True)
    is_fake = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)