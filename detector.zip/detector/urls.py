from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('input/<str:platform>/', views.input_details, name='input_details'),
]